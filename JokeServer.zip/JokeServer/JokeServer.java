


/* 


Kyle Goggio
1/19/2023
JDK 19.0.1
how to compile:  javac JokeServer.java  (twice)
To run:

Clients, Server, and ClientAdmin can can run on same machine, but in different terminals.
Clients, server, and client admin can run on different computers by passing the specified ip address when you run the program on command line


running on local host

Terminal/CMD window 1> java JokeServer
Terminal/CMD window 2 > java JokeClient
Terminal/CMD window 3 > java JokeClientAdmin
Terminal/CMD window N > java JokeClient

running  on internet:

Terminal/CMD window 1> java JokeServer
Terminal/CMD window 2> java JokeClient [IP add of JokeServer]


Files needed: 
JokeServer.java
JokeClient.java
JokeAdminClient.java


Notes

Proverbs are from Frank Herbert's Dune
Jokes are from https://parade.com/1041830/marynliles/clean-jokes/
Proverbs are from https://www.goodreads.com/work/quotes/3634639-dune




*/

import java.io.*;
import java.net.*;
import java.util.ArrayList;



class JokeData implements Serializable { //the data is sent bit by bit over the network
	String userName;
	String itemSent; //joke or proverb to be sent
	String clientInput; //pressing enter or quit, that's being passsed from client to server


	
	//silly question, but what is the advantage of serializing the class?
	//Do we serialize it to make for more fail resistant server?
	//is it for reliability/availability purposes? cause i'm sure that 
	//breaking the data down into much smaller pieces makes it a lot quicker
	
}
class AdminLooper implements Runnable {



	  public void run(){ 
	    System.out.println("In the admin looper thread");
	    
	    int q_len = 6; 
	    int port = 5050;  //admin looper port that the client admin is utilizing.
	    Socket sock;


	    try{
	      ServerSocket servSock = new ServerSocket(port, q_len); //server socket using port used by admin looper
	      while (true) { 
	    	  sock = servSock.accept(); //just waits to accept stuff incoming to port 5050
	    	  new AdminWorker (sock).start(); //adminworker thread is spawned
	      }
	    }catch (IOException ioe) {System.out.println(ioe);} //prints the ioexception
	  }
}
class AdminWorker extends Thread { 
	Socket sock;
	AdminWorker(Socket s) {sock = s;}
	
	
	public void run() {
		BufferedReader modeIn = null; //will read what's being sent from the clientadmin.java
		PrintStream modeMessage = null; //will print out what's being read by it;

		try {
			
			modeIn = new BufferedReader(new InputStreamReader(sock.getInputStream())); //reads the string input it recieves from the toggle method in the clientadmin program
			modeMessage = new PrintStream(sock.getOutputStream()); //prints out the method upon a toggle change
			modeMessage.println(JokeServer.Mode); //sends the JokeServer's mode to the JokeClientAdmin
			
			JokeServer.Mode = modeIn.readLine(); //this changes the mode based on the input recieved
			System.out.println(JokeServer.Mode);
		sock.close(); //closes the socket

	}catch (IOException IO) {
		System.out.println("Server error.");
		IO.printStackTrace();
	}
				
	}
}

class JokeWorker extends Thread { //many of these worker threads may run simultaneously bc it uses extends thread rather than implements runnable
	//the Colorworker thread is what actually does the work. the main thread just waits for clients, lets them in the door,
	//and then basically has the butler entertain the guests, which in this case is just giving each other colors
	
	Socket sock; 
	JokeWorker (Socket s) { sock = s;} 
	private static ArrayList<String> proverbsTold = new ArrayList<String>(); //keeps track of jokes  thathave been told. once it reaches 4, it clears out
	private static ArrayList<String> jokesTold = new ArrayList<String>(); //keeps track of proverbs that have been told. once it reaches a size of 4, it clears out

	static String user; //done as a static string for accessibility reasons
	
	public void run() { //this creates the thread; since JokeWorker extends the thread, each time the run function occurs and creates a thread, color worker creates and associates said new thread with a unique object
		//which is why multiple threads can run simultaneously (info from https://www.geeksforgeeks.org/implement-runnable-vs-extend-thread-in-java/)
		try {
			

			InputStream InStream = sock.getInputStream(); //this information is what the client is bringing inside the door
			ObjectInputStream ObjectIS =  new ObjectInputStream(InStream); //this creates an object input stream copy of the Instream object. 
			
			JokeData InObject = (JokeData) ObjectIS.readObject(); //gives randomaaccess to color data object sent to the server by the client. it reads what it is sent
			
			OutputStream outStream = sock.getOutputStream(); //this is the information that the server will send out the door to the client
			ObjectOutputStream objectOS = new ObjectOutputStream(outStream); //this turns the outStream into an object output stream. My question is this: what is the difference?
			//line above will also be the object containing the random color the server will send back, as well as the counter that counts how many colors the client has sent
			String user = InObject.userName; //gets user name from recieved object

			if(JokeServer.Mode.equals("joke") == true) {
			InObject.itemSent = sendJoke(user);  //checks mode. then server use the corresponding method
			
		
			} else {
				InObject.itemSent = sendProverb(user); 
				
			}

			
			objectOS.writeObject(InObject); //writes the object to the socket, passes it to the client user
			
			System.out.println("Closing the client socket connection...");
			sock.close();
		} catch(ClassNotFoundException CNF) {
			CNF.printStackTrace(); 
		}catch (IOException x) {
			System.out.println("Server error.");
			x.printStackTrace();
		}
	}
	String sendJoke(String user) {
		String u = user;
		String chosenJoke = "";
		String[] jokeArray = new String[4];

		jokeArray[0] = String.format("JA %s , What do dentists call their x-rays? \n A toothpick!" , u);
		jokeArray[1] = String.format("JB %s There's a fine line between a numerator and a denominator.", u );
		jokeArray[2] = String.format("JC %s What does a house wear? \n Address!", u);
		jokeArray[3] = String.format("JD %s What do you get from a pampered cow? \n Spoilt milk!", u);
		//this is done to add names to jokes; also means fewer data structures, as I considered using array lists instead

		if(jokesTold.size()==4) {
			jokesTold.clear();
			System.out.println("Cycle ended. Cycle now restarting");
			
		}
		while(true) { //done to make sure that the index that is randomly chosen isn't one that has already been used. 
		int rIndex = (int) (Math.random() * jokeArray.length); 
		if(!jokesTold.contains(jokeArray[rIndex])) {  //checks to see if the chosen index has been used; if it hasn't been, then it is added and ends the while loop
			chosenJoke = jokeArray[rIndex];
			jokesTold.add(chosenJoke); //adds it to the server, which is keeping state,
			return chosenJoke;
		}
		}
		
	
	}
	String sendProverb(String user) {
		String u = user;
		String[] proverbArray = new String[4];
		String chosenProverb = "";
		proverbArray[0] = String.format("PA %s What do you despise? By this are you truly known.", u);
		proverbArray[1] = String.format("PB %s The mystery of life isn't a problem to solve, but a reality to experience.", u); 
		proverbArray[2] = String.format("PC %s Hope clouds observation.", u);
		proverbArray[3] = String.format("PD %s The people who can destroy a thing, they control it.", u);
		//done this way to interleave the username and PA/PB/PC/PD
		if(proverbsTold.size()==4) {
			proverbsTold.clear();
			System.out.println("Restarting cycle");
			
			
		}
		while(true) {
		int rIndex = (int) (Math.random()* proverbArray.length);
		if(!proverbsTold.contains(proverbArray[rIndex])) { 
			chosenProverb = proverbArray[rIndex];
			proverbsTold.add(chosenProverb);
			return chosenProverb; //see comments for sendJoke
		}
		}
			
		}
}
			
		
		
		
		
	


public class JokeServer {
	static String Mode = "joke";
	public static void main(String[] args) throws Exception
	{ //this main method is listening for more connections...
		//and accepting connection requests from clients who come to the port of the server,
		//...asking to be let in
		
		int q_len = 6; //max number of simultaneous connection attempts by different client hosts assigned to be handled by a single worker thread
		int serverPort = 4545; 
		Socket sock;
		
		
		AdminLooper AL = new AdminLooper();
		Thread newThread = new Thread(AL);
		newThread.start();
		System.out.println("Kyle Goggio's Joke Server 1.0 starting up listening at port " + serverPort + ".\n");
		System.out.println("System starting in " + JokeServer.Mode);
		//line below creates a door that will let clients in. 
		ServerSocket servSock = new ServerSocket(serverPort, q_len);
		System.out.println("ServerSocket awaiting connections..."); //awaitin the clinet to say hello
		while (true) { //only way to terminate the server is to control c it/ manually kill the server; 
			//this is so that the server doesn't get tired of waiting and turn itself off--that would make it useless as a server
			sock = servSock.accept(); //this makes the server let the client inside.
			System.out.println("Connection from " + sock); //shows server's port and what the system gave us through the get next available port for the client connection
			
			new JokeWorker(sock).start(); //creates a worker thread to handle the info exchange with client, and then the server listens for the next connection
			//this thread does the bulk of the real work of this whole process
		}
	}
}



