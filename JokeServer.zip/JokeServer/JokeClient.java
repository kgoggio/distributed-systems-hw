
import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.ArrayList;

/* 

/* 


Kyle Goggio
1/19/2023
JDK 19.0.1
how to compile:  javac JokeClientAdmin.java  (twice)
To run:

Clients, Server, and ClientAdmin can can run on same machine, but in different terminals.
Clients, server, and client admin can run on different computers by passing the specified ip address when you run the program on command line


running on local host

Terminal/CMD window 1> java JokeServer
Terminal/CMD window 2 > java JokeClient
Terminal/CMD window 3 > java JokeClientAdmin
Terminal/CMD window N > java JokeClient

running  on internet:

Terminal/CMD window 1> java JokeServer
Terminal/CMD window 2> java JokeClient [IP add of JokeServer]


Files needed: 
JokeServer.java
JokeClient.java
JokeAdminClient.java


Notes

Proverbs are from Frank Herbert's Dune
Jokes are from https://parade.com/1041830/marynliles/clean-jokes/
Proverbs are from https://www.goodreads.com/work/quotes/3634639-dune




*/


public class JokeClient {
	public static ArrayList<String> proverbsTold = new ArrayList<String>();
	public static ArrayList<String> jokesTold = new ArrayList<String>();

	

	public static void main(String argv[]) {
		JokeClient cc = new JokeClient(argv);
		cc.run(argv); // argv is the string array containing commandline arguments being passed into the program
	}
	public JokeClient(String argv[]) {
		System.out.println("\n This is the constructor if you want to use it.\n"); //without this...
		//...object cc wouldn't work in line 58 without this; null ojbect, would cause problems when trying to run since object hasn't been defined
	}
	public void run(String argv[]) {
		//need  this for cc.run to actually work
		//creates a new thread on client side
		String serverName;
		int serverPort;
		
		
		if (argv.length < 1) {
			serverName = "localhost"; // this checks if a server name/ ip address was passed into the command line(it is the command line, right?)
		} 
		//if nothing is passed into the commandline, the serverNae is localhost by default
		else serverName = argv[0]; //else servername is the first commandline argument given in the array
			String clientInput = "";
			

			Scanner consoleIn = new Scanner(System.in); //takes user input on commandline/whatever console you're using to run the program
			System.out.print("Enter your name: ");
			System.out.flush(); //clears out the entered name data, clears it out after its been sent ...
			//...in order to prevent memory overflow problems (is this correct?)
			String userName = consoleIn.nextLine(); //takes user's input into the console to use to communicate with client user
			System.out.println("Hi " + userName);
			do {
				System.out.print("press 'enter' for a joke or proverb, or 'quit' to quit: ");
				clientInput = consoleIn.nextLine();
			
			

				if(clientInput.equalsIgnoreCase("quit")!=true) { //this was changed so that quit works regardless of capitalization
					getItem(userName, clientInput , serverName);
					//this passes the user name, the enter press, and the servername so that the 
					//...recieve method works. might be better to code to take out the client input, make it more functional, cause i'm not sure if i actually need this
					//...but i do know I used it as a holdover from teh colorClient version
				}
					
			} while(clientInput.equalsIgnoreCase("quit")!=true);  //this means that the program will continue running unless quit is entered
				System.out.println("Cancelled by our user request");

			
			}
		void getItem(String userName, String itemRecieved, String serverName) {
		
			try {
				String restartMessage = "null";
				JokeData jokeObj = new JokeData(); //this is using the colordata object...
				//defined in colorserver...
				//since this thing was defined in the server version of the program... 
				//...you have to compile it there first
				jokeObj.itemSent = itemRecieved;
				jokeObj.userName = userName; 
				//below was an attempt to track cycle, but it didn't work;
//				if(proverbsTold.size() == 4) {
//					proverbsTold.clear();
//					restartMessage = "Proverbs cycle restarting";
//				}
//				if(jokesTold.size() == 4) {
//					jokesTold.clear(); //this helps keep track of and clear out the cycle again; secondary redundancy in case primary redundancy fails on server side
//					//also not perfect. will try to go back to this later and see if i can play with it more so that it also serve as a secondary checker to ensure no redundant jokes some how slipped in here
//					restartMessage = "Jokes cycle restarting";
//				}
//				if( itemRecieved.contains("PA")==true) {
//					proverbsTold.add(itemRecieved);
//				} else if(itemRecieved.contains("PB")==true) {
//					proverbsTold.add(itemRecieved);
//				} else if (itemRecieved.contains("PC")==true) {
//					proverbsTold.add(itemRecieved);
//				} else if(itemRecieved.contains("PD")==true) {
//					proverbsTold.add(itemRecieved);
//				} else if(itemRecieved.contains("JA")==true) {
//					jokesTold.add(itemRecieved);
//				} else if (itemRecieved.contains("JB")==true) {
//					jokesTold.add(itemRecieved);
//				} else if (itemRecieved.contains("JC")==true) {
//					jokesTold.add(itemRecieved);
//				} else if(itemRecieved.contains("JD")==true) {
//					jokesTold.add(itemRecieved);
//				} //Although sloppy, I wanted to make sure that the state was tracked, that way
				//...the joke client would be able to help keep track of the cycle resets
				//also not very efficient, probably could have used else statements, but i wanted to be sure
					

				
				//Socket badsock = new Socket("badhost", 45565); //this demosntrates the uh exception when uncommented out
				Socket socket = new Socket(serverName, 4545); //creates a new socket with
				//System.out.println("\nWe have successfully connected to the ColorServer at port 45,565");
				
				OutputStream OutputStream = socket.getOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(OutputStream); //do we need to serialize it so that it will be..
				//...compatible with the Colorworker in ColorServer.java? doesn't the colorworker make this step redundant?
				
				oos.writeObject(jokeObj);
				//System.out.println("We have sent the serialized values to the ColorServer's server socket"); //I'm assuming this is here because if this shows...
				//...it means that oos.writeObject(colorObj) was successful
				
				InputStream InStream = socket.getInputStream(); //information coming in from the server
				ObjectInputStream ois = new ObjectInputStream(InStream); //why is it preferable to turn the input stream into an object input stream?
				JokeData InObject = (JokeData) ois.readObject();
				//colorsRecieved.add(InObject.colorSentBack);
				
				//will maintaining the conversation state using a connectionless protocol potentially...
				//...pose a security threat? or would it be the opposite case?
				//clientColorCount = InObject.colorCount; //the color count is now saved locally to the client host
				
				System.out.println("\nFROM THE SERVER:");
			    if(!restartMessage.equals("null")) {
			    	System.out.print(restartMessage);
			    }
			    System.out.println(InObject.itemSent); 


			      
			      
			    System.out.println("Closing the connection to the server.\n");
			    socket.close();
			    
			    } catch (ConnectException CE){
			      System.out.println("\nOh no. The ColorServer refused our connection! Is it running?\n");
			      CE.printStackTrace();
			    } catch (UnknownHostException UH){ //this catches if server can't find an IP address for the client... 
			    	//... .how would it not be able to get an ip address? is it an ability to spoof? VPN use?
			      System.out.println("\nUnknown Host problem.\n"); // this will trigger if the badhost line is uncommented out
			      UH.printStackTrace();
			    } catch(ClassNotFoundException CNF){// this throws if ColorClient.java can't find the color data class defined in the colorserver.java
				CNF.printStackTrace();
			    } catch (IOException IOE){
			      IOE.printStackTrace(); // This provides info to help with debuggging
			    }
			  }
						
				
				
	
}