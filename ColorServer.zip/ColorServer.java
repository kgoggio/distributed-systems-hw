


/* 

Name: Kyle Goggio
Date: 2023-1-5
Java Version: JDK 19.0.1 
Command-line compilation: > javac ColorServer.java [executed twice]
Running these programs:

Client and server can run on the same machine in different command prompts/terminals, or on
separate, internet-connected machines depending on the argument passed to the ColorClient program.

To run on localhost:

Terminal/CMD window 1> java ColorServer
Terminal/CMD window 2> java ColorClient
Terminal/CMD window 3> java ColorClient
[...]
Terminal/CMD window N> java ColorClient

Alternatively, to run over the Internet:

Terminal/CMD window 1> java ColorServer
Terminal/CMD window 2> java ColorClient 172.16.0.98 [But use the actual IP address of the ColorServer]
[...]

Files needed: 
a. ColorServer.java
b. ColorClient.java



--------------------

Thanks:

https://www.comrevo.com/2019/07/Sending-objects-over-sockets-Java-example-How-to-send-serialized-object-over-network-in-Java.html (Code dated 2019-07-09, by Ramesh)
https://rollbar.com/blog/java-socketexception/#
Also: Hughes, Shoffner and Winslow for Inet code.

--------------------



*/

import java.io.*;
import java.net.*;

class ColorData implements Serializable { //implementing serializable  means that the data is sent bit by bit over the network
	String userName;
	String colorSent;
	String colorSentBack;
	String messageToClient;
	int colorCount;
	//silly question, but what is the advantage of serializing the class?
	//Do we serialize it to make for more fail resistant server?
	//is it for reliability/availability purposes? cause i'm sure that 
	//breaking the data down into much smaller pieces makes it a lot quicker
	
}

class ColorWorker extends Thread { //many of these worker threads may run simultaneously bc it uses extends thread rather than implements runnable
	//the Colorworker thread is what actually does the work. the main thread just waits for clients, lets them in the door,
	//and then basically has the butler entertain the guests, which in this case is just giving each other colors
	Socket sock; //class member, which in this case is a socket that is local to the colorworker class
	ColorWorker (Socket s) { sock = s;} //this assigns arg s to the local socket called sock
	public void run() { //this creates the thread; since ColorWorker extends the thread, each time the run function occurs and creates a thread, color worker creates and associates said new thread with a unique object
		//which is why multiple threads can run simultaneously (info from https://www.geeksforgeeks.org/implement-runnable-vs-extend-thread-in-java/)
		try {
			
			InputStream InStream = sock.getInputStream(); //this information is what the client is bringing inside the door
			ObjectInputStream ObjectIS =  new ObjectInputStream(InStream); //this creates an object input stream copy of the Instream object. 
			
			ColorData InObject = (ColorData) ObjectIS.readObject(); //gives randoma access to color data object sent to the server by the client. it reads what it is sent
			
			OutputStream outStream = sock.getOutputStream(); //this is the information that the server will send out the door to the client
			ObjectOutputStream objectOS = new ObjectOutputStream(outStream); //this turns the outStream into an object output stream. My question is this: what is the difference?
			//line above will also be the object containing the random color the server will send back, as well as the counter that counts how many colors the client has sent
			
			System.out.println("\nFROM THE CLIENT:\n");
			System.out.println("Username: " + InObject.userName);
			System.out.println("Color sent from the client: " + InObject.colorSent);
			System.out.println("Connections count (State!): " + (InObject.colorCount + 1)); //this line and three above are for the servr's console
			
			InObject.colorSentBack = getRandomColor(); //sets the outgoing color to a random one from the set below
			InObject.colorCount++;
			InObject.messageToClient = String.format("Thanks %s for sending the color %s",  InObject.userName, InObject.colorSent);
			//line above is a string sent to the client after the client has entered name & color
			//line 100 is also a great means of doing error checking because it also allows programmer to confirm that 
			//the client has successfully sent, and the server has successfully recieved, the client's data (name and color)
			
			objectOS.writeObject(InObject); //why use writeObject? what's the difference?
			
			System.out.println("Closing the client socket connection...");
			sock.close();
		} catch(ClassNotFoundException CNF) {
			CNF.printStackTrace(); 
			//note for line above: class is defined in server code, thus the server version has to be compiled first
			//not quite sure why the CNF 
		}catch (IOException x) {
			System.out.println("Server error.");
			x.printStackTrace();
		}
	}
	String getRandomColor() {
		String[] colorArray = new String[] //creates inventory of colors to choose from
				{"Red", "Blue", "Green", "Yellow", "Magenta", "Silver", "Aqua", "Gray", "Peach", "Orange"} ;
		int randomArrayIndex = (int) (Math.random() * colorArray.length); 
		return (colorArray[randomArrayIndex]);
	}
}

public class ColorServer {
	public static void main(String[] args) throws Exception 
	{ //this main method is listening for more connections...
		//and accepting connection requests from clients who come to the port of the server,
		//...asking to be let in
		int q_len = 6; //max number of simultaneous connection attempts by different client hosts assigned to be handled by a single worker thread
		int serverPort = 45565; 
		Socket sock;
		
		System.out.println("Clark Elliott's Color Server 1.0 starting up, listening at port " + serverPort + ".\n");
		
		//line below creates a door that will let clients in. 
		ServerSocket servSock = new ServerSocket(serverPort, q_len);
		System.out.println("ServerSocket awaiting connections..."); //awaitin the clinet to say hello
		while (true) { //only way to terminate the server is to control c it/ manually kill the server; 
			//this is so that the server doesn't get tired of waiting and turn itself off--that would make it useless as a server
			sock = servSock.accept(); //this makes the server let the client inside.
			System.out.println("Connection from " + sock); //shows server's port and what the system gave us through the get next available port for the client connection
			new ColorWorker(sock).start(); //creates a worker thread to handle the info exchange with client, and then the server listens for the next connection
			//this thread does the bulk of the real work of this whole process
		}
	}
}
