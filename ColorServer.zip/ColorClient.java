

import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.ArrayList;

/* 

Name: Kyle Goggio
Date: 2023-1-5
Java Version: JDK 19.0.1
Command-line compilation: > javac ColorClient.java [executed twice]
Running these programs:


Client and server can run on the same machine in different command prompts/terminals, or on
separate, internet-connected machines depending on the argument passed to the ColorClient program.

To run on localhost:

Terminal/CMD window 1> java ColorServer
Terminal/CMD window 2> java ColorClient
Terminal/CMD window 3> java ColorClient
[...]
Terminal/CMD window N> java ColorClient

Alternatively, to run over the Internet:

Terminal/CMD window 1> java ColorServer
Terminal/CMD window 2> java ColorClient 172.16.0.98 [But use the actual IP address of the ColorServer]
[...]

Full list of files needed for running the program:
a. ColorServer.java 
b. ColorClient.java



--------------------

Thanks:

https://www.comrevo.com/2019/07/Sending-objects-over-sockets-Java-example-How-to-send-serialized-object-over-network-in-Java.html (Code dated 2019-07-09, by Ramesh)
https://rollbar.com/blog/java-socketexception/#
Also: Hughes, Shoffner and Winslow for Inet code.

--------------------
Notes: 
The Client does the state maintainence. I also modified the check for quit to ignore capitalization

*/



public class ColorClient {
	public ArrayList<String> colorsRecieved = new ArrayList<String>();
	public ArrayList<String> colorsSent = new ArrayList<String>();
	private static int clientColorCount = 0;
	public static void main(String argv[]) {
		ColorClient cc = new ColorClient(argv);
		cc.run(argv); // argv is the string array containing commandline arguments being passed into the program
	}
	public ColorClient(String argv[]) {
		System.out.println("\n This is the constructor if you want to use it.\n"); //without this...
		//...object cc wouldn't work in line 58 without this; null ojbect, would cause problems when trying to run since object hasn't been defined
	}
	public void run(String argv[]) {
		//need  this for cc.run to actually work
		//creates a new thread on client side
		String serverName;
		
		
		if (argv.length < 1) serverName = "localhost"; // this checks if a server name/ ip address was passed into the command line(it is the command line, right?)
		//if nothing is passed into the commandline, the serverNae is localhost by default
		else serverName = argv[0]; //else servername is the first commandline argument given in the array
			
			String colorFromClient = ""; //why is this indented? is it part of the else statement?
			Scanner consoleIn = new Scanner(System.in); //takes user input on commandline/whatever console you're using to run the program
			System.out.print("Enter your name: ");
			System.out.flush(); //clears out the entered name data, clears it out after its been sent ...
			//...in order to prevent memory overflow problems (is this correct?)
			String userName = consoleIn.nextLine(); //takes user's input into the console to use to communicate with client user
			System.out.println("Hi " + userName);
			do {
				System.out.print("Enter a color, or quit to send: ");
				colorFromClient = consoleIn.nextLine();
				//if(colorFromClient.indexOf("quit") <0) { //its checking to see if quit hasn't been entered
				//remember, if trying to index something that isn't in whatever you're trying to index,
				//the method will return -1; hence why its checking if its less than 0
				//changed this so that it will recognize the quit input regardless of upper/lowercase
				if(colorFromClient.equalsIgnoreCase("quit")!=true) { //this was changed so that quit works regardless of capitalization
					getColor(userName, colorFromClient, serverName);
					colorsSent.add(colorFromClient); //
					
			}
			//} while(colorFromClient.indexOf("quit")<0); //changed to allow quit to work regardless of capitalization
			} while(colorFromClient.equalsIgnoreCase("quit")!=true); //this means that the program will continue running unless quit is entered
			System.out.println("Cancelled by our user request");
			System.out.println(userName + ", You sent and recieved " + clientColorCount + " colors.");
			System.out.println("You sent the following colors: \n");
			System.out.println(colorsSent);
			System.out.println("\nYou recieved the following colors: \n");
			System.out.println(colorsRecieved);
			}
		void getColor(String userName, String colorFromClient, String serverName) {
		
			try {
				ColorData colorObj = new ColorData(); //this is using the colordata object...
				//defined in colorserver...
				//since this thing was defined in the server version of the program... 
				//...you have to compile it there first
				colorObj.userName = userName;
				colorObj.colorSent = colorFromClient; //this is all initializing the attributes of the object
				colorObj.colorCount = clientColorCount;
				
				//Socket badsock = new Socket("badhost", 45565); //this demosntrates the uh exception when uncommented out
				Socket socket = new Socket(serverName, 45565); //creates a new socket with
				System.out.println("\nWe have successfully connected to the ColorServer at port 45,565");
				
				OutputStream OutputStream = socket.getOutputStream();
				ObjectOutputStream oos = new ObjectOutputStream(OutputStream); //do we need to serialize it so that it will be..
				//...compatible with the Colorworker in ColorServer.java? doesn't the colorworker make this step redundant?
				
				oos.writeObject(colorObj);
				System.out.println("We have sent the serialized values to the ColorServer's server socket"); //I'm assuming this is here because if this shows...
				//...it means that oos.writeObject(colorObj) was successful
				
				InputStream InStream = socket.getInputStream(); //information coming in from the server
				ObjectInputStream ois = new ObjectInputStream(InStream); //why is it preferable to turn the input stream into an object input stream?
				ColorData InObject = (ColorData) ois.readObject();
				colorsRecieved.add(InObject.colorSentBack);
				
				//will maintaining the conversation state using a connectionless protocol potentially...
				//...pose a security threat? or would it be the opposite case?
				clientColorCount = InObject.colorCount; //the color count is now saved locally to the client host
				
				System.out.println("\nFROM THE SERVER:");
			    System.out.println(InObject.messageToClient); 
			    System.out.println("The color sent back is: " + InObject.colorSentBack);
			    System.out.println("The color count is: " + InObject.colorCount + "\n");
			      
			      
			    System.out.println("Closing the connection to the server.\n");
			    socket.close();
			    
			    } catch (ConnectException CE){
			      System.out.println("\nOh no. The ColorServer refused our connection! Is it running?\n");
			      CE.printStackTrace();
			    } catch (UnknownHostException UH){ //this catches if server can't find an IP address for the client... 
			    	//... .how would it not be able to get an ip address? is it an ability to spoof? VPN use?
			      System.out.println("\nUnknown Host problem.\n"); // this will trigger if the badhost line is uncommented out
			      UH.printStackTrace();
			    } catch(ClassNotFoundException CNF){// this throws if ColorClient.java can't find the color data class defined in the colorserver.java
				CNF.printStackTrace();
			    } catch (IOException IOE){
			      IOE.printStackTrace(); // This provides info to help with debuggging
			    }
			  }
						
				
				
	
}