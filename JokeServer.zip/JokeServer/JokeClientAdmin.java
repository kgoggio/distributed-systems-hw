

import java.io.*;
import java.net.*;
import java.util.Scanner;
import java.util.ArrayList;

/* 


Kyle Goggio
1/19/2023
JDK 19.0.1
how to compile:  javac JokeClientAdmin.java  (twice)
To run:

Clients, Server, and ClientAdmin can can run on same machine, but in different terminals.
Clients, server, and client admin can run on different computers by passing the specified ip address when you run the program on command line


running on local host

Terminal/CMD window 1> java JokeServer
Terminal/CMD window 2 > java JokeClient
Terminal/CMD window 3 > java JokeClientAdmin
Terminal/CMD window N > java JokeClient

running  on internet:

Terminal/CMD window 1> java JokeServer
Terminal/CMD window 2> java JokeClient [IP add of JokeServer]


Files needed: 
JokeServer.java
JokeClient.java
JokeAdminClient.java


Notes

Proverbs are from Frank Herbert's Dune
Jokes are from https://parade.com/1041830/marynliles/clean-jokes/
Proverbs are from https://www.goodreads.com/work/quotes/3634639-dune




*/


public class JokeClientAdmin {
	static String serverName;
	static String serverMode;
	public static void main(String[] args) {

		//String serverName;
		if (args.length < 1) serverName = "localhost"; // this checks if a server name/ ip address was passed into the command line(it is the command line, right?)
		//if nothing is passed into the commandline, the serverNae is localhost by default
		else serverName = args[0]; //else servername is the first commandline argument given in the array
		String clientInput; //will determine whether toggle method triggers or not
		String serverMode = "joke"; //defualt mode
		System.out.println("Client Admin has started\n Starting in joke mode");
		Scanner consoleIn = new Scanner(System.in);
			
			do {
				System.out.print("Press 'enter' to switch mode, or 'quit' to quit : ");
				System.out.flush();
				clientInput = consoleIn.nextLine();
				if(clientInput.equalsIgnoreCase("quit")!=true) {
				ToggleMode(serverMode); //toggle mode changes as long as you press enter or don't enter "quit" into console
				}
		
					
			} while(clientInput.equalsIgnoreCase("quit")!=true);  //this means that the program will continue running unless quit is entered
				System.out.println("Cancelled by our user request");

	}
	public static void ToggleMode(String mode) {
		//find a way to make sure that i'm using 
		//serialized stuff, and
		Socket socket;
		PrintStream OutputStream;
		BufferedReader input = null;
		try {
				socket = new Socket(serverName, 5050);  //creates new socket. at the host address and port 5050
				System.out.println("\nWe have successfully connected to the JokeServer at port 5050");
				OutputStream = new PrintStream(socket.getOutputStream()); //breaks down the string that's going to be sent to the server by breaking it down into its bytes
				input = new BufferedReader(new InputStreamReader(socket.getInputStream())); //reads what its recieving from the server
				
				mode = input.readLine(); //reads the message from the Print Stream that's running on the joke server side. changes upon recieving that input.
				if(mode.equals("joke")) { //this is also helpful for starting out
					OutputStream.println("proverb"); //also helps with redundancy, to make sure both clientadmin and joke server are on the same page (maybe i'm over thinking or giving myself too much credit.
					System.out.println("Now running in proverb mode"); //will play around later to see if I can try and better optimize this on my own time
				} else {
					OutputStream.println("joke"); //prints message to the joke server's buffered reader that the server should be in joke mode
					System.out.println("Now running in joke mode"); //tells clientadmin.java that its changed to joke mode, also helpful in debugging 
				}
					

			    } catch (IOException IOE){
			      IOE.printStackTrace(); //debugging info
			    }
			  }
}
						
				
				
	
