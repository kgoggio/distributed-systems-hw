import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.util.*;
import java.util.concurrent.PriorityBlockingQueue;
//Kyle Goggio
//2/27/23
//jdk 19.0.1
//command-line compilation:


//javac -cp "gson-2.8.2.jar" Blockchain.java
//java -cp ".;gson-2.8.2.jar" Block 0 
//java -cp ".;gson-2.8.2.jar" Block 1 (separete terminal/cmd prompt)
//java -cp ".;gson-2.8.2.jar" Block 2 (separete terminal/cmd prompt)
//all in that order, and all three processes must be running, and started  up in this order

//list of files needed:
//the gson library version 2.8.2.jar file
//Blockchain.java
//BlockInput0.txt
//BlockInput1.txt
//BlockInput2.txt

//notes:
//code was taken heavily from the code provided by dr. clark elliot at https://condor.depaul.edu/~elliott/435/hw/programs/Blockchain/program-block.html
/*The web sources:
Dr. Elliott's helper code from condor.depual.edu

Reading lines and tokens from a file:
http://www.fredosaurus.com/notes-java/data/strings/96string_examples/example_stringToArray.html
Good explanation of linked lists:
https://beginnersbook.com/2013/12/linkedlist-in-java-with-example/
Priority queue:
https://www.javacodegeeks.com/2013/07/java-priority-queue-priorityqueue-example.html
https://mkyong.com/java/how-to-parse-json-with-gson/
http://www.java2s.com/Code/Java/Security/SignatureSignAndVerify.htm
https://www.mkyong.com/java/java-digital-signatures-example/ (not so clear)
https://javadigest.wordpress.com/2012/08/26/rsa-encryption-example/
https://www.programcreek.com/java-api-examples/index.php?api=java.security.SecureRandom
https://www.mkyong.com/java/java-sha-hashing-example/
https://stackoverflow.com/questions/19818550/java-retrieve-the-actual-value-of-the-public-key-from-the-keypair-object
https://www.java67.com/2014/10/how-to-pad-numbers-with-leading-zeroes-in-Java-example.html
http://www.javacodex.com/Concurrency/PriorityBlockingQueue-Example
https://www.quickprogrammingtips.com/java/how-to-generate-sha256-hash-in-java.html  @author JJ
https://dzone.com/articles/generate-random-alpha-numeric  by Kunal Bhatia  ·  Aug. 09, 12 · Java Zone

-----------------------------------------------------------------------*/

class PublicKeyTable {
	//hold the public keys; these are bound to the process id number, which is set as the key node in the hashtable
    private static final Hashtable<Integer, PublicKey> PublicKeyTable = new Hashtable<Integer, PublicKey>(); //for the hash table, the integer is the key, and the values contained by the PID are the actual public keys in the key pairs
    public static void put(Integer PID, PublicKey key) {
        PublicKeyTable.put(PID, key);//sets they key to the PID input, and sets the value of the PID to the public key passed in
    }

    public static boolean containsPID(Integer pid) {
        return PublicKeyTable.containsKey(pid); //checks to make sure that the pid passed in is contained in the hashtable
    }

    public static Hashtable<Integer, PublicKey> get() {
        return PublicKeyTable; //retrieves the hash table datastructure
    }


    static int size() {
        return PublicKeyTable.size(); //returns how many keys nodes are contained in the public key table
    }
}

class BlockRecord implements Serializable { //derived from Dr. Elliott's sample code programs
    //block info
    String blockNum;//index of the block in the block chain ledger
    String BID; //unique block id number which distinguishes it from other blocks;
    String CID; //process id number of the process id that created the unverified, unhashed block before it was verified
    String signedBID; //signed block ID number
    String vPID; //the PID number of the process that verified the block
    String randSeed; //solution attempt for the work puzzle; 
    String unsignedHash; //unsigned, sha 256 hashed string containing the previous winning hash, a concatenated string containing all the dat contained in the blockrecord object, and the win
    String signedHash; //base64 encoded, signed winning hash string
    String timeStamp; //time stamp of block
    String dataHash; //this contains the signed (in sha256 with rsa),hashed patient data in a base 64 encoded  string

 

    //patient info; this is neccessary because these are the datafield contained in the block input files
    String firstName;
    String lastName;
    String DOB;
    String SSN;
    String diagnosis;
    String treatment;
    String Rx;


    public String getBlockNum() {
        return blockNum;
    } //rerieves the Block number;

    public void setBlockNum(String s) {
        this.blockNum = s;
        //sets the block number upon the verification of the block
    }


    public String getBID() {
        return BID; //retrieves block id number
    }

    public void setBID(String id) {
        this.BID = id; //sets block id number
    }

    public String getCID() {
        return CID; //retrieves CID
    }

    public void setCID(String id) {
        this.CID = id; //sets cid
    }

    public String getSignedBID() {
        return signedBID; //retrieves the signed BID string
    }

    public void setSignedBID(String sid) {
        this.signedBID = sid; //sets the signed bid string
    }

    public String getvPID() {
        return vPID;
        //retrieves the pid of the process which verified this block
    }

    public void setvPID(String id) {
        this.vPID = id;
        //sets the vpid to the  process id number of the process which verified this block
    }

    public void setRandSeed(String seed) {
        this.randSeed = seed; //sets the potential solution to the work puzzle
        //we only need to set the randseed because its contained in the unsigned hash, which is important for the verification process of new blocks
    }

    public String getUnsignedHash() {
        return unsignedHash; //this retrieves the concatenated string containing the randomseed, the signed, hashed patient data and the priorwinning hash
    }

    public void setUnsignedHash(String hash) {
        this.unsignedHash = hash; //this sets the concatenated string containing the randomseed, the signed, hashed patient data and the priorwinning hash
        
    }

    public String getSignedHash() {
        return signedHash; //retrieved the signed version othe unsigned hash
    }

    public void setSignedHash(String hash) {
        this.signedHash = hash; //sets the signed version of the unsigned hash
    }

    public String getTimeStamp() {
        return timeStamp; //retrieves the timestamp stored in the block record object
    }

    public void setTimeStamp(String date) {
        this.timeStamp = date; //sets the timestamp of the blockrecord to the string passed into the parameter
    }

    public String getDataHash() {//?
        return dataHash; //retrieves the signed data has of the patient data fields in the BlockRecord object(name,dob,ssn, etc)
    }

    public void setDataHash(String hash) {//?
        this.dataHash = hash; 
      //sets passed in string to the signed data has of the patient data fields in the BlockRecord object(name,dob,ssn, etc)
    }

    public String getFirstName() {
        return firstName;
        //retrieves the first name data contained in the BlockRecord Object
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
      //sets the first name data contained in the BlockRecord Object
    }

    public String getLastName() {
        return lastName;
        //retrieves patient last name contained in the BlockRecord Object
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
        //sets the last name data contained in the BlockRecord Object
    }

    public String getDOB() {
        return DOB;
        //retrives the DOB data contained in the BlockRecord Object
    }

    public void setDOB(String dob) {
        this.DOB = dob;
       //sets the DOB data contained in the BlockRecord Object
    }

    public String getSSN() {
        return SSN;
      //retrives the SSN contained in the BlockRecord Object
    }

    public void setSSN(String ssn) {
        this.SSN = ssn;
      //sets the SSN data contained in the BlockRecord Object
    }

    public String getDiagnosis() {
        return diagnosis;
      //retrives the diagnosis data contained in the BlockRecord Object
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
      //sets the diagnosis data contained in the BlockRecord Object
    }

    public String getTreatment() {
        return treatment;
      //retrives the treatment information data contained in the BlockRecord Object
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
        //sets the treatment information data contained in the BlockRecord Object
    }

    public String getRX() {
        return Rx;
        //retrives the medicine information data contained in the BlockRecord Object
    }

    public void setRX(String rx) {
        this.Rx = rx;
        //sets the medicine information data contained in the BlockRecord Object
    }


    public String toJson() { 
    	//this method converts the blockrecord object into a json, and returns the block record object as a json object
        Gson gson = new GsonBuilder().setPrettyPrinting().create(); //creates a new gson builder with pretty printing enables
        String json = gson.toJson(this, BlockRecord.class);// this creates a json object from the blockrecord object
        return json; //returns the new json object
    }
}


class publicKeyServer implements Runnable {
    private final int port;
    private boolean keysRecieved = false; //will be used to make sure that process 2 has sent out its keys before the other processes start doing the same

    publicKeyServer(Integer pid) {
        port = 4710 + pid; //sets the port number for the process
        PublicKeyTable.put(pid, Blockchain.keyPair.getPublic()); //adds the pid number and public key of the key pair to the hashtable
    }

    public void run() {
        int q_len = 6; //limits the simulataneous requests to 6
        Socket sock; //initializes the socket
        System.out.println("Starting Public Key Server input thread using port " + port + ".");
        try {
            //creates the door bell socket
            ServerSocket servSock = new ServerSocket(port, q_len);
            while (true) {
                sock = servSock.accept(); //door is rung, sock becomes the socket connecting the server to the client processes
                new PublicKeyWorker(sock).start(); //spawns keyworker thread at the socket variable sock
            }
        } catch (IOException x) {
            x.printStackTrace();//prints out io related errors for debugging purposes
        }

    }

    public boolean processTwoKeysRecieved() { 
        return keysRecieved; //this method checks to see if processes 0 and 1 have recieved their keys from process 2
    }

    public void sendPublicKeys(int[] PIDS, int pid, PublicKey key) { //passes in the PID array, the pid number, and the corresponding publickey
        Socket sock; 
        ObjectOutputStream out;//will send the jsons
        try {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();//creates a gson with pretty printing neabled
            byte[] byteKey = key.getEncoded(); //encodes the Publickey variable puts it in a byte array
            String stringKey = Base64.getEncoder().encodeToString(byteKey); //encodes the encoded byte array into a base64 string
            PublicKeys newKey = new PublicKeys(pid, stringKey); //creates new public key  from the encoded key string and the pid number
            String json = gson.toJson(newKey); //converts it to json
            System.out.println("Sending Process " + pid + " and  Public Key " + stringKey + "."); //lets user know the processes are sending each toher their respective public keys
            for (int i = 0; i < PIDS.length; i++) {
                sock = new Socket("localhost", 4710 + PIDS[i]); //creates a socket for each of the other processes
                out = new ObjectOutputStream(sock.getOutputStream()); //creates a new object  outstream with which to send out the string json objects
                out.writeObject(json); //sends the json strings to theo ther processes
                out.flush(); //clears the memory
                sock.close(); //break the connection
            }
        } catch (Exception x) {
            x.printStackTrace();//will print exceptions errors for debugging purposes
        }
    }

    class PublicKeys {
        //public keys will be sent in json form
         
        private final int PID; //pid number
        private final String key; //public key string

        PublicKeys(int p, String k) { //initializes the public key object, and passes in the key string and the pid number
            PID = p;
            key = k;
        }

        public int getPID() {
            return PID; //retrieves the PID number stored in the public key object
        }

        public String getKey() {
            return key; //retrieves the key stored in the public key
        }
    }

    class PublicKeyWorker extends Thread {
    	//decodes and converts the json-formatted key objects and converts them back the the public keys, and then adds the m to the public keys hashtable

        Socket sock;

        PublicKeyWorker(Socket s) {
            sock = s;
        }

        public void run() {
            Gson gson = new Gson(); // Use the gson library to store the retrieved json object
            try {
                ObjectInputStream in = new ObjectInputStream(sock.getInputStream());
                PublicKeys json = gson.fromJson((String) in.readObject(), PublicKeys.class); //converts the json strings back to public key objects
                int pid = json.getPID(); //retrieves the pid  number stored in the public  key object
                String stringKey = json.getKey(); //retrieves the public key associated with the public key object
                System.out.println("Received from Process " + pid + " and Public Key " + stringKey + ".");


                byte[] byteKey = Base64.getDecoder().decode(stringKey); //decodes the base 64 string stored in string key and loads it into a byte array
                X509EncodedKeySpec pubSpec = new X509EncodedKeySpec(byteKey); //encodes the byte array into X509 encoding
                KeyFactory keyFactory = KeyFactory.getInstance("RSA"); //key factor will use rsa
                PublicKey key = keyFactory.generatePublic(pubSpec); //creates a public key encoded to X509 standards with rsa


                if (!PublicKeyTable.containsPID(pid)) { //checks to see if the hashtable contains the pid number node; if it doesn't, it adds the node and respective key to the table
                    PublicKeyTable.put(pid, key);
                    if (pid == 2)//ifthe pid # is 2, it updates the keys received variable to true; important for the wait while loop that process 0 and 1 are stuck in while waiting for process 2 start
                        keysRecieved = true; // received the keys from process 2.
                }
            } catch (Exception x) {
                x.printStackTrace(); //used for error exceptions and debugging
            }
        }
    }

}

//this class was lifted from Dr. Elliot's BlockInputG program at: https://condor.depaul.edu/~elliott/435/hw/programs/Blockchain/BlockInputG.java
//web references are featured above, but also in the following lines below, to show which sources correlate with this specific class, and it also features alterations
//... that i made personally changes in order to integrate it alongside the other helper code programs provided by Dr. Elliott



class BlockInput {
    private static String FILENAME; //stores the file name that will be read by the blockinput process
    private final LinkedList<BlockRecord> blockList;

    BlockInput(int p) { //this ensures that ID # of the process taking in the file passes the pid into the block producer; this is especially important
    	//because it will ensure that process correctly reads the correct file and sends the contents to the other two processes
        pid = p; //sets the private final int pid to the integer variable b that's been passed into the block input constructor
        blockList = new LinkedList<BlockRecord>(); //creates a linked list of all the blockrecords read from the blockinput files
        readFiles();//reads the files for the respective process number (0,1, or 2)
    }



    private static final int iFNAME = 0; //token array index of first name will be 0 
    private static final int iLNAME = 1;//token array index of last name will be 1
    private static final int iDOB = 2; //token array index of DOB will be 2
    private static final int iSSNUM = 3;//token array index of SSN will be 3
    private static final int iDIAG = 4;//token array index of diagnosis will be 4
    private static final int iTREAT = 5;//token array index of treatment will be 5
    private static final int iRX = 6; //token array index of RX info will be 6
    private final int pid;
    LinkedList<BlockRecord> recordList = new LinkedList<BlockRecord>(); //creates a linked list of the blockrecords read by the process


    public void run() {
        //BlockInpt is forced to wait until all 3 public keys; 3 key/value nodes in the hashtable, so it will run once the table has 3 key/value pairs
        while (PublicKeyTable.size() != 3)
            System.out.print("\r"); //this is just being used to stall
        Socket s;
        ObjectOutputStream out;
        Random rand = new Random();
        try {
        Set<Integer> pids = PublicKeyTable.get().keySet();//provides the set of pid numbers as an integer set
        for(Integer pid : pids) {
        	System.out.println("now sending blocks to process " + pid);
        	for(BlockRecord record: recordList) { //iterates through the record list to send each of the 4 newly created blockrecords to the unverified blockserver ports that serve each of the 3 processes
        		s = new Socket("localhost", 4820 + pid);//creates a socket to the blockserver for each process
        		out = new ObjectOutputStream(s.getOutputStream()); //creates stream that will send out the blocks to the blockserver
        		Thread.sleep((rand.nextInt(9)*100)); //adds randomness
        		out.writeObject(record.toJson());//converts the brecord to json
        		out.flush();//clears buffer
        		}
        	}
        	System.out.println("done");
        	} catch (Exception a) {
                a.printStackTrace();//will print exception errors for debugging purposes
                }
        
    }


    //readFiles was taken and adapted from Dr. Elliot's BlockGInput.java program
    private void readFiles() { //allows each process to read its respective input text line by line, and create a blockchain block comprised of 
    	//...each of the input file's 4 patients files, then sends each one as a block chain block 
        String FILENAME;
        if (pid == 1) {
            //FILENAME = "C:/Users/kyleg/OneDrive/Desktop/ds2 workspace/DATA STRUCTURES II - 9122022 - 251 PM/algs4.zip_expanded/data/BlockInput1.txt";
            FILENAME = "BlockInput1.txt";
            //ensures process 1 reads the content of blockInput1.txt

        } else if (pid == 2) {
            //FILENAME = "C:/Users/kyleg/OneDrive/Desktop/ds2 workspace/DATA STRUCTURES II - 9122022 - 251 PM/algs4.zip_expanded/data/BlockInput2.txt";
            FILENAME = "BlockInput2.txt";
          //ensures process 2 reads the content of BlockInput.txt
        } else {
           // FILENAME = "C:/Users/kyleg/OneDrive/Desktop/ds2 workspace/DATA STRUCTURES II - 9122022 - 251 PM/algs4.zip_expanded/data/BlockInput0.txt";
            FILENAME = "BlockInput0.txt";
          //ensures that only process 0 reads the contents of BlockInput0.txt
            //this method while effective, admittedly doesn't scale well; wonder if there is a better way to do that so if someone wanted more than 3...
            //...processes with their own blockinput text file could also participate
        }

        try {
            System.out.println("Using input file: " + FILENAME); //prints out the name of the file tha tis being read

            BufferedReader br = new BufferedReader(new FileReader(FILENAME));//creates a new buffered reader that contains the contents read by the filereader...
            //this file reader reads the file contained within the FILENAME variable
            String[] tokens = new String[10]; //string array that will contain the data from the input files, which will then be added into the corresponding 
            //blockrecord data fields
            String InputLineStr; //this will be a temp string that will be used by the while loop to go through the input file string by string


            int n = 0; //index accumulator number for traversal through the buffered reader; counts number of records read by the process

            while ((InputLineStr = br.readLine()) != null) { //will go through file line by line until br.readline returns a null string, then the while
            	//...loop ends

                BlockRecord BR = new BlockRecord(); // Creates new block record for the string that's just been read from br

                try {
                    Thread.sleep(1001);
                } catch (InterruptedException e) {
                }
                Date date = new Date(); //creates new date that will be used to make the time stamp
                String T1 = String.format("%1$s %2$tF.%2$tT", "", date); //converts the date variable into a string variable
                String TimeStampString = T1 + "." + pid; // prevents timestamp collisions, and concatenates the timestamp data to include the pid of the creator of the unverified block
                System.out.println("Timestamp: " + TimeStampString);
                //adding these time stamps will allow the priority queue to correctly sort the blocks into time-stamp order when appending them to the ledger



                String suuid = UUID.randomUUID().toString();  //creates a new string variable that contains a randomly generated uuid that has been
                //..converted to string,


                BR.setBID(suuid); //sets the blockrecord BID field to the randomly generated uuid
                byte[] signedBID = Blockchain.signData(BR.getBID().getBytes(StandardCharsets.UTF_8), Blockchain.keyPair.getPrivate());
                BR.setSignedBID(Base64.getEncoder().encodeToString(signedBID));
                BR.setCID(Integer.toString(pid));//reads the number from the commandline and sets it to the cid
                BR.setvPID(""); //initializes the variable so that it can be set once it is accessed by the Block consumer thread
                BR.setTimeStamp(TimeStampString); //sets the time stamp data of the block's creatio

               
                tokens = InputLineStr.split(" +"); // separates inputline str at " +", and then each of those split up entries become a separete entry in
                //..the tokens string array
                BR.setFirstName(tokens[iFNAME]);//sets the first name to string contained in tokens[0]
                BR.setLastName(tokens[iLNAME]);//sets the last name to string contained in tokens[1]
                BR.setDOB(tokens[iDOB]);//sets the last name to string contained in tokens[2]
                BR.setSSN(tokens[iSSNUM]);//sets the SSN name to string contained in tokens[3]
                BR.setDiagnosis(tokens[iDIAG]); //sets the Diagnosis to string contained in tokens[4]
                BR.setTreatment(tokens[iTREAT]); //sets treatment to the string contained in tokens[5]
                BR.setRX(tokens[iRX]); //sets rx info to the string contained in tokens[6]
                //catString concatenates all the patient data together into one string
                StringBuilder sb = new StringBuilder(); //this will concatenate te client data
                sb.append(BR.getFirstName());
                sb.append(BR.getLastName());
                sb.append(BR.getDOB());
                sb.append(BR.getSSN());
                sb.append(BR.getDiagnosis());
                sb.append(BR.getTreatment());
                sb.append(BR.getRX());
                String catString = sb.toString(); //final concated string of patient data

                byte[] signedData = Blockchain.signData(catString.getBytes(StandardCharsets.UTF_8), Blockchain.keyPair.getPrivate()); //signs the bytes of the concatenated patient data string using the priavte key and loads them into this signedData array
                BR.setDataHash(Base64.getEncoder().encodeToString(signedData)); //sets the signedData byte array to the datahash field

                n++; //increases counter to help keep track of how many records were read
                recordList.add(BR); //adds the block record as the last node in the linkedlist of blockrecords called RecordList
            }
            br.close(); //closes the buffered reader
            System.out.println(n + "records read. \n");
        } catch (Exception e) {
            e.printStackTrace(); //prints a stack trace in case there are problems; debugging purposes
        }
    }
}

class UnverifiedBlockServer implements Runnable {

	//unverified block server accepts new unverified blocks sent to this process at
	//each port of each respective process--4820 for process 0, 4821 for process 1, and 4822 for process 2
    PriorityBlockingQueue<BlockRecord> queue; //priority que; will properly sort block by timestamp
    private final int port;

    UnverifiedBlockServer(PriorityBlockingQueue<BlockRecord> queue, int p) {  //passes a reference to the  priority blocking queue in main, as well as the pid #
        this.queue = queue; //contrstuctor that sets the passed in que to a local variable
        port = 4820 + p;//contructor; makes the passed in pid number + 4820 to a local variable called port
    }

    class UnverifiedBlockServerWorker extends Thread {

    	//reads recieved blocks and changes them from json objects to BlockRecord objects
        Socket sock;

        UnverifiedBlockServerWorker(Socket s) {
            sock = s; //initializes socket s as sock
        }

        BlockRecord block = new BlockRecord(); //local blockrecord object

        public void run() {
            try {
                Gson gson = new Gson(); //creates new gson object
                ObjectInputStream in = new ObjectInputStream(sock.getInputStream()); //creates a new input stream that recieves the json objects
                block = gson.fromJson((String) in.readObject(), BlockRecord.class);// Coverts the recieved json object to a BlockRecord object.
                queue.put(block); // adds the blockrecord block to the priority blocking queue
                sock.close(); //closes the stack trace
            } catch (Exception x) {
                x.printStackTrace(); //prints the stack trace in the event of errors; helpful for debugging
            }
        }
    }

    public void run() { //starts the unverified blockServer thread that's waiting for input data from the three data input files
        int q_len = 6; //limits the amount of simultaneous connections from client processes to 6 max
        Socket s; //initializes the socket
        System.out.println("Starting the Unverified Block server input thread port " + port); //prints message informing user what port number will be takining in the input threads
        try {
            ServerSocket servSock = new ServerSocket(port, q_len); //creates server doorbell socket
            while (true) {
                s = servSock.accept(); //door bell has been run; the server socket accepts the connection
                new UnverifiedBlockServerWorker(s).start(); //now that the socket has accepted the socket connection, it spawns a n unverifiedBlockServerWorker thread at socket S
            }
        } catch (IOException ioe) {
            System.out.println(ioe);//prints out input/output exception error in the event an error occurs, helpful for debugging
        }
    }
}


class UnverifiedBlockConsumer implements Runnable {


    final PriorityBlockingQueue<BlockRecord> queue; // this is a local version of the passed in reference to the priority que heled in the main method
    final LinkedList<BlockRecord> ledger; //local version of the linkedlist ledger variable created in the main method; contains the blockchain ledger of verified nodes

    private final int PID;

    UnverifiedBlockConsumer(PriorityBlockingQueue<BlockRecord> a, LinkedList<BlockRecord> b, int pid) { //this  is a passed in reference to the blocking queue and linked list objects created in the main method

        queue = a; //localizes the passed in blocking queue
        ledger = b;//localizes the passed  in linked list
        PID = pid; //localizes the referenced to the passed in process id number
        if (pid == 2) {        
        	//since process 2 starts the everything, process 2 must create the genesis block of the block chain

            //this was all derived from Dr. Elliott's BlockJ program

            BlockRecord gBlock = new BlockRecord(); //creates the genesis block BlockRecord object
            try {

                Date date = new Date(); //sets the date, which will be used to create the block's timestamp
                String BID = UUID.randomUUID().toString(); //sets uuid
                String T1 = String.format("%1$s %2$tF.%2$tT", "", date); //creates time stampe
                String TimeStampString = T1 + "." + pid; // this prevents timestamp collisions; program sets the timestamp of the block to this 
                //...timeStamp string
                System.out.println("Timestamp: " + TimeStampString); //prints out the time stamp for debugging purposes


                gBlock.setBID(BID); //the BID is 0 since it is the genesis block.
                byte[] sBID = Blockchain.signData(gBlock.getBID().getBytes(StandardCharsets.UTF_8), Blockchain.keyPair.getPrivate());
                //sBID contains the signed byte array of the bytes of the BID string data
                gBlock.setSignedBID(Base64.getEncoder().encodeToString(sBID)); //
                gBlock.setCID(Integer.toString(pid)); 
                gBlock.setTimeStamp(TimeStampString);//sets the time stamp of the time at which the gblock was created
                gBlock.setFirstName("Steven"); //sets first name of gblock
                gBlock.setLastName("Johnson");//sets last name of gblock
                gBlock.setDOB("10.01.99");//sets dob of gblock
                gBlock.setSSN("123-45-6789");//sets the fake ssn of the block
                gBlock.setDiagnosis("too cool for school"); //sets fake diagnosis
                gBlock.setTreatment(" skip school"); //sets fake treatment
                gBlock.setRX("no school!"); //sets fake rx of the genesis block


                StringBuilder catRecord = new StringBuilder(); //this string builder creates a concatonated string of the patient data
                catRecord.append(gBlock.getFirstName());//retrieves and appends the first name data from the unverified block to the string builder
                catRecord.append(gBlock.getLastName());//retrieves and appends the last name data from the unverified block to the string builder
                catRecord.append(gBlock.getDOB());//retrieves and appends the DOB  from the unverified block to the string builder
                catRecord.append(gBlock.getSSN());//retrieves and appends the SSN from the unverified block to the string builder
                catRecord.append(gBlock.getDiagnosis());//retrieves and appends the diagnosis data from the unverified block to the string builder
                catRecord.append(gBlock.getTreatment());//retrieves and appends the treatment data from the unverified block to the string builder
                catRecord.append(gBlock.getRX());//retrieves and appends the RX data from the unverified block to the string builder

                String stringRecord = catRecord.toString(); //this variable is string version of the catRecord string builder

                byte[] signedDataHashBytes = Blockchain.signData(stringRecord.getBytes(StandardCharsets.UTF_8), Blockchain.keyPair.getPrivate());
                //signedDataHashBytes array was created by:
                //1 using the getBytes() method to create a byte array version of String record
                // andpassing byte array of string record and the private key retrived with the .keyPair.getPrivate method into the signData method
                //2. the method uses the byte array and key passed in to create a signed byte array of the patient data, and returns a new byte array containing the 
                //signed byte array which contains patient data assembled by stringRecord
                //in otherwords, the bytes of the concatenated patient data are signed and loaded into the signed dataHash
                String stringSignedDataHash = Base64.getEncoder().encodeToString(signedDataHashBytes); //this takes the signed byte array above and encodes it 
                //into an base64-encoded string
                gBlock.setDataHash(stringSignedDataHash);//the dataHash string of the block is now set to the signed patient data that was encoded into a base 64 string

                byte[] array = new byte[3]; //creates a new byte array that will be used to create the randomseed
                new Random().nextBytes(array);//creates new random random bytes and loads them into the initializedbyte array
                String randomSeed = new String(array, StandardCharsets.UTF_8);//takes the randomized byte array contents and converts them into a string cnsisting of utf-8 characters
                gBlock.setRandSeed(randomSeed); //sets the random  seed
                gBlock.setvPID("2");//no verification process here; just a dummy, and since process 2 is creating the dummy block, i set the vpid to process 2
                gBlock.setBlockNum("0"); //dummy block is first block in the chain

                catRecord.append(gBlock.getvPID());//adds this data to the concatenated string
                catRecord.append(gBlock.getBlockNum()); //adds the block number to the concatenated string

                String workString = stringSignedDataHash + catRecord + randomSeed; //this  contains the signed data hash, the full concatenated block record string and the reandom seed, these are what verify the block

                MessageDigest ourMD = MessageDigest.getInstance("SHA-256"); //initializes a massage digest object taht utilizes the sha-256 algorithm
                ourMD.update(workString.getBytes(StandardCharsets.UTF_8));//loads the bytes of workstring into the MD object
                byte[] workBytes = ourMD.digest();//hashes the bytes and loads it into a byte array
                String workHash = Blockchain.ByteArrayToString(workBytes);//converts the byte array toa string variable
                gBlock.setUnsignedHash(workHash); //this sets the hashed, concatenated string containeing the signed hasshed patient data, the concatenated blockrecord,

                byte[] signedHash = Blockchain.signData(workBytes, Blockchain.keyPair.getPrivate());//creates a signed byte array out of sha256-hashed byte array which is signed using the private key
                gBlock.setSignedHash(Base64.getEncoder().encodeToString(signedHash));//sets the signed hash of the block
                System.out.println("Gen block created by process " + pid);
                sendBlock(gBlock, PublicKeyTable.get().keySet());//this sends the dummy genesis block to all three
            } catch (Exception e) {
                e.printStackTrace(); //stack for debugging
            }
        }

        try {
            Thread.sleep(5000); //makes sure that the genesis block is sent before anything else happens
        } catch (InterruptedException e) {
            e.printStackTrace(); //done for debugging purposes
        }
    }

    public void run() {
        try {
            while (!queue.isEmpty()) {//as long as there are nodes in the queue, the consumer threads will keep running
                System.out.println(queue.size() + " nodes left to validate"); //checks how many unverified nodes are left in the queue
                boolean contestRunning = true; //will be used to inform the processes that a black has now been verified
                BlockRecord unvBlock = queue.take(); //pops the block into a new loca block 
                while (contestRunning) { //while the race to verify a block is continuing...
                    boolean blockalreadyhere = false; //will be used to check if the block being examined has already been added to the ledger
                    System.out.println("ledgersize is " + ledger.size());//lets us know how large the ledger is; useful for debuggin or later expansion
                    for (BlockRecord vBlock : ledger) { //for each loop; will check to make sure that the unv block isn't already in the ledger
                        if (unvBlock.getBID().equals(vBlock.getBID())) { //checks if the unverified block record's BID is already there; 
                        	//...if the BID matches, there's no shadow of a doubt that the block is already in there
                            System.out.println("Block: " + unvBlock.getBID() + "in blockchain"); //lets user know the block is already there, and the iterator breaks
                            blockalreadyhere = true; //now we know the block is already here
                            contestRunning = false;//therefore break loop, don't let processes compete to verify this block
                            break; //breaks for loop--no reason to go any further through the list since its  clear the block in question has already been verified
                        }
                    }
                    if (!blockalreadyhere) { //if the block isn't in the ledger, then start getting to work verifying
                        int CID = Integer.parseInt(unvBlock.getCID()); //takes the numerical value of the string form of the stored number
                        byte[] BID = unvBlock.getBID().getBytes(StandardCharsets.UTF_8);
                        byte[] sig = Base64.getDecoder().decode(unvBlock.getSignedBID()); //the based 64 string is then decoded back into its signed byte
                        //...array form and loaded into this sig variable
                        if (Blockchain.verifySig(BID, PublicKeyTable.get().get(CID), sig)) { //uses the key of the unverified block's creator to 
                            System.out.println("Block " + unvBlock.getBID() + " 's ID is now verified.");
                        } else {
                            System.out.println("BID " + unvBlock.getBID() + "'s ID not verifiable.");
                            System.out.println("discarding");
                            break;
                        }
                        byte[] sDHash = Base64.getDecoder().decode(unvBlock.getDataHash());
                        StringBuilder blockToHash = new StringBuilder(); //this strinbuilder is being used to concatenate the patient data in a form that can then be used to get
                        blockToHash.append(unvBlock.getFirstName()); ////retrieves and appends the first name data from the unverified block to the string builder
                        blockToHash.append(unvBlock.getLastName()); //retrieves and appends the last name data from the unverified block to the string builder
                        blockToHash.append(unvBlock.getDOB()); //retrieves and appends the DOB  from the unverified block to the string builder
                        blockToHash.append(unvBlock.getSSN()); //retrieves and appends the SSN from the unverified block to the string builder
                        blockToHash.append(unvBlock.getDiagnosis()); //retrieves and appends the diagnosis data from the unverified block to the string builder
                        blockToHash.append(unvBlock.getTreatment()); //retrieves and appends the treatment data from the unverified block to the string builder
                        blockToHash.append(unvBlock.getRX()); //retrieves and appends the RX data from the unverified block to the string builder
                        byte[] blockBytes = blockToHash.toString().getBytes(StandardCharsets.UTF_8); //converts the string builder into a string, then
                        //...creates a byte array from the bytes of the "blockToHash" string
                        if (Blockchain.verifySig(blockBytes, PublicKeyTable.get().get(CID), sDHash)) { //if the Blockchain program, using the verifySig method, manages to return true...
                        	//...which confirms that the unverified block's signature was confirmed...
                            System.out.println("Block " + unvBlock.getBID() + " had its data hash verified."); //...then it is printed on console informing user that the block was verified successfully
                        } else {
                            System.out.println("Block " + unvBlock.getBID() + " could not have its data hash verified."); //prints message to console that data signature wasn't verified; protects againt fraud
                            break;
                        }

                       

                        byte[] array = new byte[3]; //creates a new byte array that will be used to create the randomseed
                        new Random().nextBytes(array);//creates new random random bytes and loads them into the initializedbyte array
                        String randomSeed = new String(array, StandardCharsets.UTF_8);//takes the randomized byte array contents and converts them into a string cnsisting of utf-8 characters
                        int blockNum = 0;  //counter; will be used to give the blockrecord the correct index number when added to the eldger
                        String priorWinningHash = ""; //must initialize this in order for it to wwork
                        for (BlockRecord vBlock : ledger) {
                            blockNum = Integer.parseInt(vBlock.getBlockNum()); //updates the counter number to the highest blocknumber currentlyiin the blockcahin ledger
                            priorWinningHash = vBlock.getUnsignedHash(); //sets the prior winning by retrieving
                        }

                        unvBlock.setBlockNum(Integer.toString(1 + blockNum)); //sets the block's blocknumber to 1+ the highest index
                        unvBlock.setvPID(Integer.toString(PID)); //sets the verifying pid to the pid number of the process attempting verification
                        blockToHash.append(unvBlock.getvPID()); //adds the vPID to the concatenated string
                        blockToHash.append(unvBlock.getBlockNum());//adds the block  number to the concatenated string

                        MessageDigest MD = MessageDigest.getInstance("SHA-256");//initializes a one-way sha 256 hash function
                        MD.update((priorWinningHash + blockToHash.toString() + randomSeed).getBytes(StandardCharsets.UTF_8)); //concatenates previous hash, the unverifiedblockrecord object data, and the random seed (puzzle solution attempt) to the message digest as a byte array
                        byte[] bytesHash = MD.digest(); //this hashes the string into a byte array
                        String workHash = Blockchain.ByteArrayToString(bytesHash); //converts the byte array to string using the byteArrayToString method
                        int workedNum = Integer.parseInt(workHash.substring(0, 4), 16); //parses the wo
                        if (workedNum > 5000) {  // lower number = more work; assists in 
                            System.out.format("%d is not less than 5,000 so we did not solve the puzzle\n\n", workedNum);
                            //prints out a notice that the process didn't successfully solve the puzzle; helps for debugging, and provides an overview 
                            //of what's happening while the ledger is being built

                        }
                        if (workedNum < 5000) {
                        	//if the number is less than 10,000 then it solves the puzzle.
                            System.out.format("%d IS less than 5,000 so puzzle solved!\n", workedNum);
                            System.out.println("The seed (puzzle answer) was: " + randomSeed);
                            byte[] signedHash = Blockchain.signData(bytesHash, Blockchain.keyPair.getPrivate());
                            unvBlock.setUnsignedHash(workHash); //sets the unsigned hashed data of the prior winning hash, the hashed block record, and the winning randomseed
                            unvBlock.setSignedHash(Base64.getEncoder().encodeToString(signedHash));//encodes the signedHash to string-formatted base 64 encodding, and sets it to the signedHash field
                            unvBlock.setRandSeed(randomSeed); //this sets the random seed to the winning puzzle solution
                            contestRunning = false; //block ahs been verified, stop trying to solve the puzzle!
                            sendBlock(unvBlock, PublicKeyTable.get().keySet()); //sends the set of keys stored in the Public key hash table,  and the unverified block, to the ledger linked list
                            break;
                        }
                        Thread.sleep(2000); //adds additional fake work

                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();//prints out stack trace in case of an error exception; will help with debugging
        }
    }


    public void sendBlock(BlockRecord block, Set<Integer> PIDs) { //the pids of each of the three keys
        Socket sock; //creates the socket via which the the BlockRecord block object will be sent to the other processes
        ObjectOutputStream out; //this creates the object outputstream that the socket will use to send the outgoing object to the socket
        try {
            // Send each BlockRecord block object to the other nodes;
            for (Integer pid : PIDs) {
                System.out.println("Sending Verified Block to " + pid + "...");
                sock = new Socket("localhost", 4930 + pid); //sends it to local host at each process' correlating port; two processes cna't use the same port;...
                //...process 0 uses 4930 to send the blocks, process 1 uses 4931 to send its blocks and process 2 uses 4932 to send its respective blocks. 
                out = new ObjectOutputStream(sock.getOutputStream());
                out.writeObject(block.toJson()); //converts the block BlockRecord object to JSON, then marshals it to the other processes
                out.flush();//clears out the memory buffers
                sock.close(); //breaks off the connection now that the object has been sent to the other two processes.
            }
        } catch (Exception x) {
            x.printStackTrace(); //provides error data in the event of errors or program crashes; useful for debugging
        }
    }
}


class LedgerServer implements Runnable {
	//the leger server maintains and updates the blockchain ledger
	//it recieves the verified nodes and adds them to the blockchain ledger
    private final int port; 
    private final int pid;
    LinkedList<BlockRecord> ledger; //this is the block chain ledger, which contains all the verified blocks

    LedgerServer(LinkedList<BlockRecord> l, int p) { //passes the port so that the ledger
        pid = p;//creates a local pid fromt he passed in p integer
        port = 4930 + pid; //creates a local port number integer using pid and adding it to 4930
        ledger = l; //creates a local instance of the leger linked list variable
    }

    class LedgerServerWorker extends Thread {
    	
    	//this worker class recieves the json formatted version of the verified blockrecord objects...
    	//...then it reads these json objects, converts them back to blockrecord objects...
    	//...and then adds the verified block records as nodes of the Blockchain ledger, which is a linked list containing 
    	//...the verified blockrecord blocks.
    	Socket sock; //ledger serverworker socket is initialized;

        LedgerServerWorker(Socket s) {
            sock = s; //object constructor of the LedgerServerWorker, which passes in Socket s into the initial data attributes
        } 

        public void run() {
            BlockRecord block; //local temp blockrecord object
            try {
                Gson gson = new Gson(); //creates new gson object
                ObjectInputStream in = new ObjectInputStream(sock.getInputStream()); //revieves the block from the socket
                block = gson.fromJson((String) in.readObject(), BlockRecord.class);// in reads the object and casts it into string, which is then converted to
                //...a BlockRecord object, which the variable block is then set to.

                System.out.println("Received Verified Block from Process " + block.getvPID() + "."); //informs the user which process verified the block and sent the block to the ledger server

                ledger.add(block); //adds the verified block to the LinkedList of BlockRecord objects to our ledger to the tail end of the list
                sock.close(); //breaks the connection
                if (pid == 0) //checks to see if the data came from process 0; if so, then the ledger is printed
                    printLedger(); // Node 0 prints the updated ledger every time ledger linkedlist object is updated
            } catch (Exception x) {
                x.printStackTrace(); //this will print a stack trace in the event there's a problem; helps with debugging
            }
        }
    }

    public void run() {
    	//this run is actually for the Ledger server;
    	//this thread creates the the doorbell socket that will accept verified blocks from other processes
        int q_len = 6; //limits the number of simultaneous (at that very instant, down to the miliseconds) of time when the doorbell server socket is rung, to a maximum of 6 clients
        Socket sock;
        System.out.println("Starting The Ledger Server at " + port); //tells the user what port number is being utilized for the ledger server
        try {
            ServerSocket servSock = new ServerSocket(port, q_len); //creates doorbells socket for the ledgerserver; there will be three of these, one for each respective process
            while (true) {
                sock = servSock.accept();//this means that the doorbell socket has received a new connection; doorbell has been rung
                (new LedgerServerWorker(sock)).start(); //this spawns a ledgerServerWorker thread
            }
        } catch (IOException ioe) {
            System.out.println(ioe); //in the event that there are Input/output errors; helpful for debugging
        }
    }

    private void printLedger() {
        //this iterates through the ledger for each BlockRecord object contained in the ledger, and prints out the block and its number...
         //...and then prints out each block item in json form
        int count = 0; //counter variable
        for (BlockRecord block : ledger) {
            System.out.println("Block " + count + ": "); //this tells you what index you are at in the chain, starting from 0, the genesis block
            System.out.println(block.toJson()); //this converts the block to JSON format and print it on console; this includes all data contained in all fields within the Blockrecord object
            count++; //this accumulator will keep track of the index of each block in the ledger
        }
    }
}


public class Blockchain {
    public static KeyPair keyPair;

    //compares the timestamps of the blocks, and will sort the nodes by timestamp
    //this is from Dr. Elliot's BlockInputG.java program
    public static Comparator<BlockRecord> BlockTSComparator = new Comparator<BlockRecord>() {
        public int compare(BlockRecord b1, BlockRecord b2) {
            String s1 = b1.getTimeStamp(); 
            String s2 = b2.getTimeStamp();
            if (s1 == s2) {
                return 0;
            }
            if (s1 == null) {
                return -1;
            }
            if (s2 == null) {
                return 1;
            }
            return s1.compareTo(s2);
        }
    };


    public static void main(String[] args) throws Exception {
        final int pid = Integer.parseInt(args[0]); // reads the pid entered on commandline when the program is started
        keyPair = generateKeyPair(new Random().nextLong()); // generate the public key and private key
        final PriorityBlockingQueue<BlockRecord> PriorityQueue = new PriorityBlockingQueue<BlockRecord>(100, BlockTSComparator);
        //above is the priority blocking queue shared by all three servers and their respective processes
        
        final LinkedList<BlockRecord> Ledger = new LinkedList<>(); //block chain ledger is contained in this linked list of block records

        
        publicKeyServer pubKeyServer = new publicKeyServer(pid);//creates the keyserver for each of the processes
        UnverifiedBlockServer unvBlockServer = new UnverifiedBlockServer(PriorityQueue, pid); //creates the unverified block server for each of the processes, and passes in a reference to the priority que
        //...passes in a copy of the final priority que
        LedgerServer ledgerServer = new LedgerServer(Ledger, pid); //creates a ledgerserver for each of the three processes, and passes in the priority que from main; e

        new Thread(pubKeyServer).start(); //starts teh public key server for each respective process
        new Thread(unvBlockServer).start(); //starts the unverfied block server, which will start the creation, sending of, and verification of each 
        new Thread(ledgerServer).start(); //starts the ledger server

        // Initiate the sending of the public keys
        int[] PIDS = new int[2]; //this array holds the pid #s of the other processes
        
        if(pid==0) { //for process 0,this ensures that the keys are sent to processes 1 and 2
        	PIDS[0] = 1;
        	PIDS[1] = 2;
            // Wait until Process 2 sends its public key.
            while (!pubKeyServer.processTwoKeysRecieved()) {
                System.out.print("\r"); //processes 1 and 0 are patiently waiting for 2, just doing his print message to inform 
                //..user that 1 and 0 are running and  just waiting for process 2 to start
            }
            pubKeyServer.sendPublicKeys(PIDS, pid, keyPair.getPublic());//now that process 2 has sent its keys to 0 and 1, processes 0 and 1 will send...
            //...their keys to the other processes
        } else if(pid==1) { //this ensures that process 1 sends the keys to processes 0 and 2
        	PIDS [0] = 0;
        	PIDS[1] = 2;
            // Wait until Process 2 sends its public key.
            while (!pubKeyServer.processTwoKeysRecieved()) {
                System.out.print("\r"); //processes 1 and 0 are patiently waiting for 2, just doing his print message to inform 
                //..user that 1 and 0 are running and  just waiting for process 2 to start
            }
            pubKeyServer.sendPublicKeys(PIDS, pid, keyPair.getPublic());//now that process 2 has sent its keys to 0 and 1, processes 0 and 1 will send...
            //...their keys to the other processes
        } else {
        	PIDS[0] = 0; //this means that process 2 will send its keys to processes 0 and 1
        	PIDS[1] = 1;
        	
            //checks to see if the process running is process 2; if it is, this starts the multicasting of keys
        	//in the meantime, process 0 and 1 are patiently wating for 2, since 2 must be the process that kickstarts everything
            System.out.println(PIDS[0] + " " + PIDS[1]);
            pubKeyServer.sendPublicKeys(PIDS, pid, keyPair.getPublic());  //sends the proccess 2 public keys to processes 0 and 1
        }



        BlockInput BlockInput = new BlockInput(pid); //starts the fileinput reading thread for each process
        BlockInput.run(); //spawns the block input reading thread

        
        UnverifiedBlockConsumer unverifiedBlockConsumer = new UnverifiedBlockConsumer(PriorityQueue, Ledger, pid); //passes a reference to the  priority que, the ledger linked list object, and the process ID
        unverifiedBlockConsumer.run(); //starts the blockconsumer thread

        Thread.sleep(2000); 

        if (pid == 0) {
            createLedgerJson(Ledger); //this ensures that Block 0 is the one that creates the json ledger upon its update
        }
    }

  //this method was taken from Dr. Clark's BlockJ.java program code
    public static KeyPair generateKeyPair(long seed) throws Exception { 

        KeyPairGenerator keyGenerator = KeyPairGenerator.getInstance("RSA"); //generates the RSA key pairs
        SecureRandom rng = SecureRandom.getInstance("SHA1PRNG", "SUN"); //creates a secure pseudo random hash using sha1 with sun as the provider
        rng.setSeed(seed); //sets the seed to the long integer
        keyGenerator.initialize(1024, rng); //sets the keypair size for 1024 bits, with set random seed

        return (keyGenerator.generateKeyPair()); //generates the key pair and returns it.
    }

    public static byte[] signData(byte[] data, PrivateKey key) throws Exception {
    	//this method was taken from Dr. Clark's BlockJ.java program code
    	//this method signs the byte array with the private key, using the sha256 with rsa as the signing algorithm
        Signature signer = Signature.getInstance("SHA256withRSA"); //creates an instance of the signature class the implements SHA256 with RSA as the signing algorithm. 
        signer.initSign(key);//initializes the object for signing using the PrivateKey key
        signer.update(data);//adds in the byte array that's about to be signed
        return (signer.sign()); //returns a signed byte array
    }

    public static String ByteArrayToString(byte[] byteArray) {
    	int len = byteArray.length;
    	StringBuffer sb = new StringBuffer();
    	for (int i = 0; i < len; i++) {
    		sb.append(Integer.toString((byteArray[i] & 0xff) + 0x100, 16).substring(1)); //converts the byte array to hex format
    	}
    	return sb.toString();//converts the string builder to string, returning a string  form of the byte array when called, giving us a sha256-hashed string

    }

    
  //this method was taken from Dr. Clark's BlockJ.java program code

    public static boolean verifySig(byte[] data, PublicKey key, byte[] sig) throws Exception {

        Signature signer = Signature.getInstance("SHA256withRSA"); //creates a signature object that will utilize SHA256 with RSA as its signing algorithm
        signer.initVerify(key); //sets the key to be used to verify the data contained in the byte arry called data
        signer.update(data); //this enteres the byte array which is going to be verified

        return (signer.verify(sig)); //takes the data to see if, when encoded into sha256 with rsa, the resulting byte array matches the "sig" byte array variable;
        //if  it does, that means the signature was verifed, and then the method will return as true, and false  otherwise
    }


    //this was taken from Dr. Elliot's code from BlockInputG.java
    public static void createLedgerJson(LinkedList<BlockRecord> Ledger) {
         //this createas the json file from the linkedList that contains the ledger of verified blocks
         
        Gson gson = new GsonBuilder().setPrettyPrinting().create(); //creates the new gson object

        // the try catch writes the linkedlist of verified block records (AKA the blockchain ledger of verified blocks) to file
        try (FileWriter writer = new FileWriter("BlockchainLedgerSample.json")) {
            gson.toJson(Ledger, writer); //converts the gson object to json, and then writes it to file
        } catch (IOException e) {
            e.printStackTrace(); //Input/Output error catcher; will catch erorrs caused as the data is sent to file; great for debuggin
        }
    }
}
